BEGIN TRANSACTION;
CREATE TABLE audit_logs (
	id INTEGER NOT NULL, 
	action VARCHAR(100) NOT NULL, 
	entity_type VARCHAR(50) NOT NULL, 
	entity_id INTEGER, 
	details TEXT, 
	timestamp DATETIME NOT NULL, 
	user_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
);
CREATE TABLE board_images (
	id INTEGER NOT NULL, 
	path VARCHAR(500) NOT NULL, 
	description VARCHAR(200), 
	created_at DATETIME NOT NULL, 
	board_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(board_id) REFERENCES board_units (id)
);
INSERT INTO "board_images" VALUES(1,'C:/Users/leona/OneDrive/Documentos/PROJETO TN ELETROSISTEM 2/placa apc.png','Imagem da placa asdfasf','2026-10-01 16:42:12.193186',3);
INSERT INTO "board_images" VALUES(2,'C:/Users/manic/Documents/projeto-tn/placa_exemplo_2.jpg','Imagem da placa Placa de Teste Principal','2026-10-01 17:27:38.394016',1);
CREATE TABLE board_models (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	version VARCHAR(50) NOT NULL, 
	description TEXT, 
	created_at DATETIME NOT NULL, manufacturer VARCHAR(100), equipment VARCHAR(100), category VARCHAR(50), voltage VARCHAR(50), 
	PRIMARY KEY (id)
);
INSERT INTO "board_models" VALUES(1,'Placa X1','1.0','Placa de demonstração principal','2026-10-01 16:37:27.812623',NULL,NULL,NULL,NULL);
INSERT INTO "board_models" VALUES(2,'asdfasf','1.0',NULL,'2026-10-01 16:42:00.547740',NULL,NULL,NULL,NULL);
CREATE TABLE board_units (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	model VARCHAR(50) NOT NULL, 
	version VARCHAR(50) NOT NULL, 
	serial_number VARCHAR(100) NOT NULL, 
	created_at DATETIME NOT NULL, 
	is_active BOOLEAN NOT NULL, 
	model_id INTEGER NOT NULL, 
	operator_id INTEGER NOT NULL, client VARCHAR(100), service_order VARCHAR(50), reported_defect TEXT, diagnosis TEXT, machine_id INTEGER REFERENCES machines(id), 
	PRIMARY KEY (id), 
	UNIQUE (serial_number), 
	FOREIGN KEY(model_id) REFERENCES board_models (id), 
	FOREIGN KEY(operator_id) REFERENCES users (id)
);
INSERT INTO "board_units" VALUES(1,'Placa de Teste Principal','X1','1.0','SN001','2026-10-01 16:37:27.828171',1,1,1,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "board_units" VALUES(2,'Placa de Desenvolvimento','X1','1.0','SN002','2026-10-01 16:37:27.828177',1,1,2,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "board_units" VALUES(3,'asdfasf','asdfasf','1.0','1213123','2026-10-01 16:42:00.551373',1,2,1,NULL,NULL,NULL,NULL,NULL);
CREATE TABLE components (
	id INTEGER NOT NULL, 
	refdes VARCHAR(50) NOT NULL, 
	type VARCHAR(50) NOT NULL, 
	value VARCHAR(50), 
	part_number VARCHAR(100), 
	description TEXT, 
	x INTEGER, 
	y INTEGER, 
	board_model_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(board_model_id) REFERENCES board_models (id)
);
CREATE TABLE instruments (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	type VARCHAR(50) NOT NULL, 
	visa_address VARCHAR(100) NOT NULL, 
	manufacturer VARCHAR(100), 
	model VARCHAR(100), 
	serial_number VARCHAR(100), 
	is_active BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (visa_address)
);
CREATE TABLE machines (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	code VARCHAR(50), 
	description TEXT, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE measurements (
	id INTEGER NOT NULL, 
	value FLOAT, 
	min_limit FLOAT, 
	max_limit FLOAT, 
	unit VARCHAR(20), 
	passed BOOLEAN, 
	error_message TEXT, 
	notes TEXT, 
	timestamp DATETIME NOT NULL, 
	test_run_id INTEGER NOT NULL, 
	step_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(test_run_id) REFERENCES test_runs (id), 
	FOREIGN KEY(step_id) REFERENCES test_steps (id)
);
CREATE TABLE test_plans (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	version VARCHAR(50) NOT NULL, 
	description TEXT, 
	is_active BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	board_model_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(board_model_id) REFERENCES board_models (id)
);
CREATE TABLE "test_points" (
            id INTEGER NOT NULL PRIMARY KEY,
            refdes VARCHAR(50) NOT NULL,
            x INTEGER NOT NULL,
            y INTEGER NOT NULL,
            expected_voltage_v FLOAT,
            expected_current_a FLOAT,
            expected_frequency_hz FLOAT,
            expected_waveform VARCHAR(100),
            tolerance_voltage_v FLOAT,
            tolerance_current_a FLOAT,
            tolerance_frequency_hz FLOAT,
            notes TEXT,
            created_at DATETIME NOT NULL,
            board_id INTEGER NOT NULL,
            FOREIGN KEY(board_id) REFERENCES board_units (id)
        );
INSERT INTO "test_points" VALUES(1,'TP1',100,100,3.3,NULL,NULL,NULL,0.1,NULL,NULL,NULL,'2026-10-01 16:37:27.831970',1);
INSERT INTO "test_points" VALUES(2,'TP2',200,150,5.0,NULL,NULL,NULL,0.2,NULL,NULL,NULL,'2026-10-01 16:37:27.831978',1);
INSERT INTO "test_points" VALUES(3,'GND',150,200,0.0,NULL,NULL,NULL,0.0,NULL,NULL,NULL,'2026-10-01 16:37:27.831980',1);
INSERT INTO "test_points" VALUES(4,'VCC',524,140,12.0,NULL,NULL,NULL,0.5,NULL,NULL,NULL,'2026-10-01 16:37:27.831981',1);
INSERT INTO "test_points" VALUES(5,'vcc',761,257,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-10-01 16:42:57.113715',3);
INSERT INTO "test_points" VALUES(6,'dsdsdsss',465,234,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-10-04 11:51:19.042486',1);
CREATE TABLE test_runs (
	id INTEGER NOT NULL, 
	start_time DATETIME NOT NULL, 
	end_time DATETIME, 
	status VARCHAR(20) NOT NULL, 
	notes TEXT, 
	board_id INTEGER NOT NULL, 
	operator_id INTEGER NOT NULL, 
	plan_id INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(board_id) REFERENCES board_units (id), 
	FOREIGN KEY(operator_id) REFERENCES users (id), 
	FOREIGN KEY(plan_id) REFERENCES test_plans (id)
);
CREATE TABLE test_steps (
	id INTEGER NOT NULL, 
	description TEXT NOT NULL, 
	test_type VARCHAR(50), 
	unit VARCHAR(20), 
	desired_value FLOAT, 
	tolerance FLOAT, 
	min_limit FLOAT, 
	max_limit FLOAT, 
	order_index INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	notes TEXT, 
	plan_id INTEGER NOT NULL, 
	test_point_id INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(plan_id) REFERENCES test_plans (id), 
	FOREIGN KEY(test_point_id) REFERENCES test_points (id)
);
CREATE TABLE users (
	id INTEGER NOT NULL, 
	username VARCHAR(50) NOT NULL, 
	password_hash VARCHAR(100) NOT NULL, 
	role VARCHAR(20) NOT NULL, 
	created_at DATETIME NOT NULL, 
	is_active BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (username)
);
INSERT INTO "users" VALUES(1,'admin','$2b$12$i54Uno2To5EjCuI7CQ7bWur7ByXCDEY.Z/A.pVVmK0v8VUMA3apKq','admin','2026-10-01 16:37:27.825027',1);
INSERT INTO "users" VALUES(2,'operator','$2b$12$CQed8IgAv51A5xQX0s9keuCY371Ifm6O4Xh5QPyTlPtxugrELrNhu','operator','2026-10-01 16:37:27.825034',1);
COMMIT;
