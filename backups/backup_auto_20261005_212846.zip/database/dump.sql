BEGIN TRANSACTION;
CREATE TABLE audit_logs (
	id INTEGER NOT NULL, 
	action VARCHAR(100) NOT NULL, 
	entity_type VARCHAR(50) NOT NULL, 
	entity_id INTEGER, 
	details TEXT, 
	timestamp DATETIME NOT NULL, 
	user_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
);
CREATE TABLE board_images (
	id INTEGER NOT NULL, 
	path VARCHAR(500) NOT NULL, 
	description VARCHAR(200), 
	created_at DATETIME NOT NULL, 
	board_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(board_id) REFERENCES board_units (id)
);
INSERT INTO "board_images" VALUES(1,'C:/Users/leona/OneDrive/Documentos/PROJETO TN ELETROSISTEM 2/placa apc.png','Imagem da placa asdfasf','2026-10-01 16:42:12.193186',3);
INSERT INTO "board_images" VALUES(2,'C:/Users/leona/OneDrive/Documentos/PROJETO TN ELETROSISTEM 2/placa_exemplo_2.jpg','Imagem da placa Placa de Teste Principal','2026-10-01 17:27:38.394016',1);
INSERT INTO "board_images" VALUES(3,'C:/Users/leona/OneDrive/Documentos/PROJETO TN ELETROSISTEM 2/imagens/Diagrama Técnico do Inversor de Frequência_1.png',NULL,'2026-10-04 20:09:38.072200',4);
CREATE TABLE board_models (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	version VARCHAR(50) NOT NULL, 
	description TEXT, 
	created_at DATETIME NOT NULL, manufacturer VARCHAR(100), equipment VARCHAR(100), category VARCHAR(50), voltage VARCHAR(50), 
	PRIMARY KEY (id)
);
INSERT INTO "board_models" VALUES(1,'Placa X1','1.0','Placa de demonstração principal','2026-10-01 16:37:27.812623',NULL,NULL,NULL,NULL);
INSERT INTO "board_models" VALUES(2,'asdfasf','1.0',NULL,'2026-10-01 16:42:00.547740',NULL,NULL,NULL,NULL);
INSERT INTO "board_models" VALUES(3,'ass','sssss',NULL,'2026-10-04 20:09:38.058995',NULL,NULL,NULL,NULL);
CREATE TABLE board_units (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	model VARCHAR(50) NOT NULL, 
	version VARCHAR(50) NOT NULL, 
	serial_number VARCHAR(100) NOT NULL, 
	created_at DATETIME NOT NULL, 
	is_active BOOLEAN NOT NULL, 
	model_id INTEGER NOT NULL, 
	operator_id INTEGER NOT NULL, client VARCHAR(100), service_order VARCHAR(50), reported_defect TEXT, diagnosis TEXT, machine_id INTEGER REFERENCES machines(id), 
	PRIMARY KEY (id), 
	UNIQUE (serial_number), 
	FOREIGN KEY(model_id) REFERENCES board_models (id), 
	FOREIGN KEY(operator_id) REFERENCES users (id)
);
INSERT INTO "board_units" VALUES(1,'Placa de Teste Principal','X1','1.0','SN001','2026-10-01 16:37:27.828171',1,1,1,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "board_units" VALUES(3,'asdfasf','asdfasf','1.0','1213123','2026-10-01 16:42:00.551373',1,2,1,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "board_units" VALUES(4,'placa de controle','ass','sssss','sssss','2026-10-04 20:09:38.070867',1,3,1,NULL,NULL,NULL,NULL,1);
CREATE TABLE components (
	id INTEGER NOT NULL, 
	refdes VARCHAR(50) NOT NULL, 
	type VARCHAR(50) NOT NULL, 
	value VARCHAR(50), 
	part_number VARCHAR(100), 
	description TEXT, 
	x INTEGER, 
	y INTEGER, 
	board_model_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(board_model_id) REFERENCES board_models (id)
);
CREATE TABLE instruments (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	type VARCHAR(50) NOT NULL, 
	visa_address VARCHAR(100) NOT NULL, 
	manufacturer VARCHAR(100), 
	model VARCHAR(100), 
	serial_number VARCHAR(100), 
	is_active BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (visa_address)
);
CREATE TABLE machines (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	code VARCHAR(50), 
	description TEXT, 
	created_at DATETIME NOT NULL, image_path VARCHAR(500), 
	PRIMARY KEY (id)
);
INSERT INTO "machines" VALUES(1,'inversor de frequencia',NULL,NULL,'2026-10-04 20:04:51.887824','C:/Users/manic/Documents/projeto-tn/imagens/Diagrama Técnico do Inversor de Frequência.png');
CREATE TABLE measurements (
	id INTEGER NOT NULL, 
	value FLOAT, 
	min_limit FLOAT, 
	max_limit FLOAT, 
	unit VARCHAR(20), 
	passed BOOLEAN, 
	error_message TEXT, 
	notes TEXT, 
	timestamp DATETIME NOT NULL, 
	test_run_id INTEGER NOT NULL, 
	step_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(test_run_id) REFERENCES test_runs (id), 
	FOREIGN KEY(step_id) REFERENCES test_steps (id)
);
INSERT INTO "measurements" VALUES(1,NULL,NULL,NULL,'V',NULL,NULL,'Pulado: Sem ponto de teste','2026-10-05 17:28:16.254716',1,1);
INSERT INTO "measurements" VALUES(2,NULL,NULL,NULL,'V',NULL,NULL,'Pulado: Sem ponto de teste','2026-10-05 17:28:21.379164',2,1);
CREATE TABLE oscilloscope_captures (
	id INTEGER NOT NULL, 
	test_point_id INTEGER NOT NULL, 
	channel INTEGER NOT NULL, 
	vpp_v FLOAT, 
	vrms_v FLOAT, 
	vmax_v FLOAT, 
	vmin_v FLOAT, 
	vavg_v FLOAT, 
	frequency_hz FLOAT, 
	period_s FLOAT, 
	duty_cycle_pct FLOAT, 
	vertical_offset_v FLOAT, 
	oscilloscope_id VARCHAR(250), 
	raw_json TEXT, 
	waveform_json TEXT, 
	timestamp DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(test_point_id) REFERENCES test_points (id) ON DELETE CASCADE
);
CREATE TABLE point_measurements (
	id INTEGER NOT NULL, 
	test_point_id INTEGER NOT NULL, 
	value FLOAT NOT NULL, 
	unit VARCHAR(20) NOT NULL, 
	measurement_type VARCHAR(40) NOT NULL, 
	raw_response TEXT, 
	raw_unit VARCHAR(20), 
	multimeter_id VARCHAR(200), 
	timestamp DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(test_point_id) REFERENCES test_points (id) ON DELETE CASCADE
);
INSERT INTO "point_measurements" VALUES(1,8,1.197997931387230252e+01,'V','voltage_dc','11.9799793 V','V','Multímetro simulado','2026-10-05 20:57:24.588949');
INSERT INTO "point_measurements" VALUES(2,8,1.200756560076708723e+01,'V','voltage_dc','12.0075656 V','V','Multímetro simulado','2026-10-05 20:57:30.412766');
INSERT INTO "point_measurements" VALUES(3,8,1.197739847610196761e+01,'V','voltage_dc','11.9773985 V','V','Multímetro simulado','2026-10-05 20:57:35.604837');
INSERT INTO "point_measurements" VALUES(4,8,1.199314138989216793e+01,'V','voltage_dc','11.9931414 V','V','Multímetro simulado','2026-10-05 20:57:39.667026');
INSERT INTO "point_measurements" VALUES(5,8,1.200084680371421441e+01,'V','voltage_dc','12.0008468 V','V','Multímetro simulado','2026-10-05 20:57:39.819314');
INSERT INTO "point_measurements" VALUES(6,8,1.200847475255310571e+01,'V','voltage_dc','12.0084748 V','V','Multímetro simulado','2026-10-05 20:57:39.971174');
INSERT INTO "point_measurements" VALUES(7,8,1.201501995125409649e+01,'V','voltage_dc','12.01502 V','V','Multímetro simulado','2026-10-05 20:57:40.111159');
INSERT INTO "point_measurements" VALUES(8,8,1.202164269488272196e+01,'V','voltage_dc','12.0216427 V','V','Multímetro simulado','2026-10-05 20:57:40.276740');
INSERT INTO "point_measurements" VALUES(9,8,1.202623759961661599e+01,'V','voltage_dc','12.0262376 V','V','Multímetro simulado','2026-10-05 20:57:40.428932');
INSERT INTO "point_measurements" VALUES(10,8,1.202913068989174406e+01,'V','voltage_dc','12.0291307 V','V','Multímetro simulado','2026-10-05 20:57:40.584757');
INSERT INTO "point_measurements" VALUES(11,8,1.202999871578713708e+01,'V','voltage_dc','12.0299987 V','V','Multímetro simulado','2026-10-05 20:57:40.721264');
INSERT INTO "point_measurements" VALUES(12,8,1.202895147886299121e+01,'V','voltage_dc','12.0289515 V','V','Multímetro simulado','2026-10-05 20:57:40.882685');
INSERT INTO "point_measurements" VALUES(13,8,1.202544633348119873e+01,'V','voltage_dc','12.0254463 V','V','Multímetro simulado','2026-10-05 20:57:41.055058');
INSERT INTO "point_measurements" VALUES(14,8,1.202016465087190511e+01,'V','voltage_dc','12.0201647 V','V','Multímetro simulado','2026-10-05 20:57:41.217107');
INSERT INTO "point_measurements" VALUES(15,8,1.201255596972632489e+01,'V','voltage_dc','12.012556 V','V','Multímetro simulado','2026-10-05 20:57:41.396687');
INSERT INTO "point_measurements" VALUES(16,8,1.199621701274069351e+01,'V','voltage_dc','11.996217 V','V','Multímetro simulado','2026-10-05 20:57:41.725077');
INSERT INTO "point_measurements" VALUES(17,8,1.198826533381181392e+01,'V','voltage_dc','11.9882653 V','V','Multímetro simulado','2026-10-05 20:57:41.887106');
INSERT INTO "point_measurements" VALUES(18,8,1.19808169838126073e+01,'V','voltage_dc','11.980817 V','V','Multímetro simulado','2026-10-05 20:57:42.058799');
INSERT INTO "point_measurements" VALUES(19,8,1.19753233146796152e+01,'V','voltage_dc','11.9753233 V','V','Multímetro simulado','2026-10-05 20:57:42.218874');
INSERT INTO "point_measurements" VALUES(20,8,1.197214622846032839e+01,'V','voltage_dc','11.9721462 V','V','Multímetro simulado','2026-10-05 20:57:42.350846');
INSERT INTO "point_measurements" VALUES(21,8,1.197011594441203818e+01,'V','voltage_dc','11.9701159 V','V','Multímetro simulado','2026-10-05 20:57:42.522968');
INSERT INTO "point_measurements" VALUES(22,8,1.197071362712416943e+01,'V','voltage_dc','11.9707136 V','V','Multímetro simulado','2026-10-05 20:57:42.703261');
INSERT INTO "point_measurements" VALUES(23,8,1.197397183646775787e+01,'V','voltage_dc','11.9739718 V','V','Multímetro simulado','2026-10-05 20:57:42.880836');
INSERT INTO "point_measurements" VALUES(24,8,1.197976201151938014e+01,'V','voltage_dc','11.979762 V','V','Multímetro simulado','2026-10-05 20:57:43.063156');
INSERT INTO "point_measurements" VALUES(25,8,1.198839806741906244e+01,'V','voltage_dc','11.9883981 V','V','Multímetro simulado','2026-10-05 20:57:43.265119');
INSERT INTO "point_measurements" VALUES(26,8,1.200480137080371534e+01,'V','voltage_dc','12.0048014 V','V','Multímetro simulado','2026-10-05 20:57:43.593250');
INSERT INTO "point_measurements" VALUES(27,8,1.201375654070820787e+01,'V','voltage_dc','12.0137565 V','V','Multímetro simulado','2026-10-05 20:57:43.778914');
INSERT INTO "point_measurements" VALUES(28,8,1.202193143817311238e+01,'V','voltage_dc','12.0219314 V','V','Multímetro simulado','2026-10-05 20:57:43.980967');
INSERT INTO "point_measurements" VALUES(29,8,1.202762419798699157e+01,'V','voltage_dc','12.0276242 V','V','Multímetro simulado','2026-10-05 20:57:44.187018');
INSERT INTO "point_measurements" VALUES(30,8,1.202980033412996441e+01,'V','voltage_dc','12.0298003 V','V','Multímetro simulado','2026-10-05 20:57:44.354792');
INSERT INTO "point_measurements" VALUES(31,8,1.20291213894397444e+01,'V','voltage_dc','12.0291214 V','V','Multímetro simulado','2026-10-05 20:57:44.565411');
INSERT INTO "point_measurements" VALUES(32,8,1.202454636976958468e+01,'V','voltage_dc','12.0245464 V','V','Multímetro simulado','2026-10-05 20:57:44.782991');
INSERT INTO "point_measurements" VALUES(33,8,1.201117081717497293e+01,'V','voltage_dc','12.0111708 V','V','Multímetro simulado','2026-10-05 20:57:47.419138');
INSERT INTO "point_measurements" VALUES(34,8,1.201768333137210832e+01,'V','voltage_dc','12.0176833 V','V','Multímetro simulado','2026-10-05 20:57:47.565503');
INSERT INTO "point_measurements" VALUES(35,8,1.197351334750700146e+01,'V','voltage_dc','11.9735133 V','V','Multímetro simulado','2026-10-05 20:57:49.679147');
INSERT INTO "point_measurements" VALUES(36,8,1.197053015223231042e+01,'V','voltage_dc','11.9705302 V','V','Multímetro simulado','2026-10-05 20:57:49.855935');
INSERT INTO "point_measurements" VALUES(37,8,1.197013139163595775e+01,'V','voltage_dc','11.9701314 V','V','Multímetro simulado','2026-10-05 20:57:50.021762');
INSERT INTO "point_measurements" VALUES(38,8,1.197559005116463737e+01,'V','voltage_dc','11.9755901 V','V','Multímetro simulado','2026-10-05 20:57:50.331607');
INSERT INTO "point_measurements" VALUES(39,8,1.198133887601708913e+01,'V','voltage_dc','11.9813389 V','V','Multímetro simulado','2026-10-05 20:57:50.495775');
INSERT INTO "point_measurements" VALUES(40,8,1.199529883176050938e+01,'V','voltage_dc','11.9952988 V','V','Multímetro simulado','2026-10-05 20:57:50.798121');
INSERT INTO "point_measurements" VALUES(41,8,1.200454509089889398e+01,'V','voltage_dc','12.0045451 V','V','Multímetro simulado','2026-10-05 20:57:50.980148');
INSERT INTO "point_measurements" VALUES(42,8,1.201307386194150694e+01,'V','voltage_dc','12.0130739 V','V','Multímetro simulado','2026-10-05 20:57:51.155931');
INSERT INTO "point_measurements" VALUES(43,8,1.202008403692380689e+01,'V','voltage_dc','12.020084 V','V','Multímetro simulado','2026-10-05 20:57:51.322149');
INSERT INTO "point_measurements" VALUES(44,8,1.202615754244357583e+01,'V','voltage_dc','12.0261575 V','V','Multímetro simulado','2026-10-05 20:57:51.513686');
INSERT INTO "point_measurements" VALUES(45,8,1.202939719378501593e+01,'V','voltage_dc','12.0293972 V','V','Multímetro simulado','2026-10-05 20:57:51.696560');
INSERT INTO "point_measurements" VALUES(46,8,1.199241673345975024e+01,'V','voltage_dc','11.9924167 V','V','Multímetro simulado','2026-10-05 20:57:56.584991');
INSERT INTO "point_measurements" VALUES(47,8,1.198551561189013092e+01,'V','voltage_dc','11.9855156 V','V','Multímetro simulado','2026-10-05 20:57:56.731059');
INSERT INTO "point_measurements" VALUES(48,8,1.197641475572933346e+01,'V','voltage_dc','11.9764148 V','V','Multímetro simulado','2026-10-05 20:57:56.966783');
INSERT INTO "point_measurements" VALUES(49,8,1.1972070486420332e+01,'V','voltage_dc','11.9720705 V','V','Multímetro simulado','2026-10-05 20:57:57.138845');
INSERT INTO "point_measurements" VALUES(50,8,1.197004874689714172e+01,'V','voltage_dc','11.9700487 V','V','Multímetro simulado','2026-10-05 20:57:57.325129');
INSERT INTO "point_measurements" VALUES(51,8,1.197137049230840588e+01,'V','voltage_dc','11.9713705 V','V','Multímetro simulado','2026-10-05 20:57:57.537156');
INSERT INTO "point_measurements" VALUES(52,8,1.197368210647819886e+01,'V','voltage_dc','11.9736821 V','V','Multímetro simulado','2026-10-05 20:57:57.653177');
INSERT INTO "point_measurements" VALUES(53,8,1.197034334784282449e+01,'V','voltage_dc','11.9703433 V','V','Multímetro simulado','2026-10-05 21:03:52.084756');
INSERT INTO "point_measurements" VALUES(54,8,1.201280494476603166e+01,'V','voltage_dc','12.0128049 V','V','Multímetro simulado','2026-10-05 21:03:53.357239');
INSERT INTO "point_measurements" VALUES(55,8,1.201967596888407997e+01,'V','voltage_dc','12.019676 V','V','Multímetro simulado','2026-10-05 21:03:53.518616');
INSERT INTO "point_measurements" VALUES(56,8,1.202558550580275921e+01,'V','voltage_dc','12.0255855 V','V','Multímetro simulado','2026-10-05 21:03:53.698670');
INSERT INTO "point_measurements" VALUES(57,8,1.202867315718606279e+01,'V','voltage_dc','12.0286732 V','V','Multímetro simulado','2026-10-05 21:03:53.846230');
INSERT INTO "point_measurements" VALUES(58,8,1.202999045461057647e+01,'V','voltage_dc','12.0299905 V','V','Multímetro simulado','2026-10-05 21:03:54.006994');
INSERT INTO "point_measurements" VALUES(59,8,12.0292570561639,'V','voltage_dc','12.0292571 V','V','Multímetro simulado','2026-10-05 21:03:54.153017');
INSERT INTO "point_measurements" VALUES(60,8,12.0228975237241,'V','voltage_dc','12.0228975 V','V','Multímetro simulado','2026-10-05 21:03:54.435048');
INSERT INTO "point_measurements" VALUES(61,8,1.201129137031026595e+01,'V','voltage_dc','12.0112914 V','V','Multímetro simulado','2026-10-05 21:03:54.718838');
INSERT INTO "point_measurements" VALUES(62,8,1.200311500169420498e+01,'V','voltage_dc','12.003115 V','V','Multímetro simulado','2026-10-05 21:03:54.884642');
INSERT INTO "point_measurements" VALUES(63,8,1.19882412679708672e+01,'V','voltage_dc','11.9882413 V','V','Multímetro simulado','2026-10-05 21:03:55.182747');
INSERT INTO "point_measurements" VALUES(64,8,1.198118465629458739e+01,'V','voltage_dc','11.9811847 V','V','Multímetro simulado','2026-10-05 21:03:55.344611');
INSERT INTO "point_measurements" VALUES(65,8,1.197601606926943595e+01,'V','voltage_dc','11.9760161 V','V','Multímetro simulado','2026-10-05 21:03:55.490773');
INSERT INTO "point_measurements" VALUES(66,8,1.197205712171705727e+01,'V','voltage_dc','11.9720571 V','V','Multímetro simulado','2026-10-05 21:03:55.650724');
INSERT INTO "point_measurements" VALUES(67,8,1.197013062483175716e+01,'V','voltage_dc','11.9701306 V','V','Multímetro simulado','2026-10-05 21:03:55.924741');
CREATE TABLE test_plans (
	id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	version VARCHAR(50) NOT NULL, 
	description TEXT, 
	is_active BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	board_model_id INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(board_model_id) REFERENCES board_models (id)
);
INSERT INTO "test_plans" VALUES(1,'sdsds','dsdsds','',1,'2026-10-05 17:11:43.892760',3);
INSERT INTO "test_plans" VALUES(2,'dsddddddd','dd','',1,'2026-10-05 17:11:56.030750',3);
INSERT INTO "test_plans" VALUES(3,'xzz','zx','',1,'2026-10-05 17:21:20.611774',3);
CREATE TABLE "test_points" (
            id INTEGER NOT NULL PRIMARY KEY,
            refdes VARCHAR(50) NOT NULL,
            x INTEGER NOT NULL,
            y INTEGER NOT NULL,
            expected_voltage_v FLOAT,
            expected_current_a FLOAT,
            expected_frequency_hz FLOAT,
            expected_waveform VARCHAR(100),
            tolerance_voltage_v FLOAT,
            tolerance_current_a FLOAT,
            tolerance_frequency_hz FLOAT,
            notes TEXT,
            created_at DATETIME NOT NULL,
            board_id INTEGER NOT NULL, marker_color VARCHAR(7) NOT NULL DEFAULT '#E53935', last_measured_value FLOAT, last_measured_unit VARCHAR(20), last_measured_type VARCHAR(40), last_measured_at DATETIME, last_multimeter_id VARCHAR(200), last_scope_channel INTEGER, last_scope_vpp_v FLOAT, last_scope_vrms_v FLOAT, last_scope_frequency_hz FLOAT, last_scope_duty_pct FLOAT, last_scope_at DATETIME, last_oscilloscope_id VARCHAR(250),
            FOREIGN KEY(board_id) REFERENCES board_units (id)
        );
INSERT INTO "test_points" VALUES(1,'TP1',100,100,3.3,NULL,NULL,NULL,0.1,NULL,NULL,NULL,'2026-10-01 16:37:27.831970',1,'#E53935',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "test_points" VALUES(2,'TP2',200,150,5.0,NULL,NULL,NULL,0.2,NULL,NULL,NULL,'2026-10-01 16:37:27.831978',1,'#E53935',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "test_points" VALUES(3,'GND',150,200,0.0,NULL,NULL,NULL,0.0,NULL,NULL,NULL,'2026-10-01 16:37:27.831980',1,'#E53935',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "test_points" VALUES(4,'VCC',524,140,12.0,NULL,NULL,NULL,0.5,NULL,NULL,NULL,'2026-10-01 16:37:27.831981',1,'#E53935',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "test_points" VALUES(6,'dsdsdsss',465,234,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-10-04 11:51:19.042486',1,'#E53935',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "test_points" VALUES(7,'fghfhf',663,169,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-10-05 16:09:39.390849',3,'#E53935',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "test_points" VALUES(8,'fddfdd',237,93,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-10-05 16:43:42.008479',4,'#E53935',1.197013062483175716e+01,'V','voltage_dc','2026-10-05 21:03:55.924741','Multímetro simulado',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "test_points" VALUES(9,'ggfgfgf',73,65,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-10-05 16:43:49.837632',4,'#E53935',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "test_points" VALUES(10,'kkkk',777,218,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-10-05 16:53:02.781751',3,'#E53935',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
CREATE TABLE test_runs (
	id INTEGER NOT NULL, 
	start_time DATETIME NOT NULL, 
	end_time DATETIME, 
	status VARCHAR(20) NOT NULL, 
	notes TEXT, 
	board_id INTEGER NOT NULL, 
	operator_id INTEGER NOT NULL, 
	plan_id INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(board_id) REFERENCES board_units (id), 
	FOREIGN KEY(operator_id) REFERENCES users (id), 
	FOREIGN KEY(plan_id) REFERENCES test_plans (id)
);
INSERT INTO "test_runs" VALUES(1,'2026-10-05 20:28:15.733909','2026-10-05 20:28:16.250653','completed',NULL,4,1,1);
INSERT INTO "test_runs" VALUES(2,'2026-10-05 20:28:20.860741','2026-10-05 20:28:21.377676','completed',NULL,4,1,1);
CREATE TABLE test_steps (
	id INTEGER NOT NULL, 
	description TEXT NOT NULL, 
	test_type VARCHAR(50), 
	unit VARCHAR(20), 
	desired_value FLOAT, 
	tolerance FLOAT, 
	min_limit FLOAT, 
	max_limit FLOAT, 
	order_index INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	notes TEXT, 
	plan_id INTEGER NOT NULL, 
	test_point_id INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(plan_id) REFERENCES test_plans (id), 
	FOREIGN KEY(test_point_id) REFERENCES test_points (id)
);
INSERT INTO "test_steps" VALUES(1,'asdad',NULL,'V',NULL,NULL,NULL,NULL,1,'2026-10-05 17:28:10.751923','dasda',1,NULL);
CREATE TABLE users (
	id INTEGER NOT NULL, 
	username VARCHAR(50) NOT NULL, 
	password_hash VARCHAR(100) NOT NULL, 
	role VARCHAR(20) NOT NULL, 
	created_at DATETIME NOT NULL, 
	is_active BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (username)
);
INSERT INTO "users" VALUES(1,'admin','$2b$12$i54Uno2To5EjCuI7CQ7bWur7ByXCDEY.Z/A.pVVmK0v8VUMA3apKq','admin','2026-10-01 16:37:27.825027',1);
INSERT INTO "users" VALUES(2,'operator','$2b$12$CQed8IgAv51A5xQX0s9keuCY371Ifm6O4Xh5QPyTlPtxugrELrNhu','operator','2026-10-01 16:37:27.825034',1);
CREATE INDEX ix_point_measurements_timestamp ON point_measurements (timestamp);
CREATE INDEX ix_point_measurements_test_point_id ON point_measurements (test_point_id);
CREATE INDEX ix_oscilloscope_captures_test_point_id ON oscilloscope_captures (test_point_id);
CREATE INDEX ix_oscilloscope_captures_timestamp ON oscilloscope_captures (timestamp);
COMMIT;
